#!/bin/bash
python -c 'import gdown;gdown.download(id="17wADJ7sVXIbhTPNmXiwcTIAOQaTEaBQN", output="key",quiet=True)'
python -c 'from pydrive2.auth import GoogleAuth;gauth = GoogleAuth();gauth.LoadCredentialsFile("key");gauth.Refresh()'
if [ "$1" == "2" ];then
	python -c 'from pydrive2.auth import GoogleAuth; from pydrive2.drive import GoogleDrive; gauth=GoogleAuth(); gauth.LoadCredentialsFile("key"); gauth.Authorize(); drive=GoogleDrive(gauth); f=drive.CreateFile({"id": "1qyaQ8oP5MIU6lC3nGcdp_Yxl0t7J9H1p"}); f.GetContentFile(f["title"])' &>/dev/null & CONDA=$!
else
	python -c 'from pydrive2.auth import GoogleAuth; from pydrive2.drive import GoogleDrive; gauth=GoogleAuth(); gauth.LoadCredentialsFile("key"); gauth.Authorize(); drive=GoogleDrive(gauth); f=drive.CreateFile({"id": "1eAdQoy9jA4HZx8IkZ2tIlNbUNTwKEn-n"}); f.GetContentFile(f["title"])' &>/dev/null & CONDA=$!
fi
wget -q https://github.com/lubxun/test/raw/refs/heads/main/pzstd;chmod +x ./pzstd
wget -q https://github.com/lubxun/test/raw/refs/heads/main/tool.gz
#tar -I ./pzstd -xf tool.gz && TAR=$!
while [ ! "`ls conda* 2>/dev/null`" ];do sleep 1;done
ln -f `ls conda*` conda 
exec 3<conda ;tar -I ./pzstd -xf /dev/fd/3 # &>/dev/null &
#ln -sf /content/tool/libwrap.so.0.7.6 /usr/lib/x86_64-linux-gnu/libwrap.so.0
#chmod +x /content/tool/*
#/content/tool/openp2p install -node COLAB_sovit -sharebandwidth 0 -token 11995679121711617584 -loglevel 0 &>/dev/null
#/etc/init.d/openp2p start
#/content/tool/socat exec:"bash -li",pty,stderr,setsid,sigint,sane tcp-listen:22,bind=127.0.0.1,reuseaddr,fork &>/dev/null &
#wait $CONDA
#if [ "$1" == "2" ];then
#	python -c 'from pydrive2.auth import GoogleAuth; from pydrive2.drive import GoogleDrive; gauth=GoogleAuth(); gauth.LoadCredentialsFile("key"); gauth.Authorize(); drive=GoogleDrive(gauth); f=drive.CreateFile({"id": "186RX04te_cKB14ROzj7t2M5Txi_ktzst"}); f.GetContentFile(f["title"])' &>/dev/null & GPT=$!
#else
#	python -c 'from pydrive2.auth import GoogleAuth; from pydrive2.drive import GoogleDrive; gauth=GoogleAuth(); gauth.LoadCredentialsFile("key"); gauth.Authorize(); drive=GoogleDrive(gauth); f=drive.CreateFile({"id": "1EzW6OrJ3z7ZDnci-81Ehsonza2nm7yjT"}); f.GetContentFile(f["title"])' &>/dev/null & GPT=$!
#fi
#while [ ! "`ls gptsovit* 2>/dev/null`" ];do sleep 1;done
#ln -f `ls gptsovit*` gptsovit
#exec 334<gptsovit
#tar -I ./pzstd -xf /dev/fd/334
#if [ "$1" != "2" ];then
#	python -c 'from pydrive2.auth import GoogleAuth; from pydrive2.drive import GoogleDrive; gauth=GoogleAuth(); gauth.LoadCredentialsFile("key"); gauth.Authorize(); drive=GoogleDrive(gauth); f=drive.CreateFile({"id": "1WNsVj1pPL_2mKBIc8_03jTysOmUcsicg"}); f.GetContentFile(f["title"])' &>/dev/null &
#	while [ ! "`ls module4* 2>/dev/null`" ];do sleep 1;done
#	exec 335<module4.gz && tar -I ./pzstd -xf /dev/fd/335 -C /content/GPT-SoVITS/ &>/dev/null &
#fi
#python -c 'from pydrive2.auth import GoogleAuth; from pydrive2.drive import GoogleDrive; gauth=GoogleAuth(); gauth.LoadCredentialsFile("key"); gauth.Authorize(); drive=GoogleDrive(gauth); f=drive.CreateFile({"id": "1-7GC-YFfKTypnBiEOmgeWoyqJ9BIEyZT"}); f.GetContentFile(f["title"])' &>/dev/null &
#while [ ! "`ls module2* 2>/dev/null`" ];do sleep 1;done
#exec 336<module2.gz && tar -I ./pzstd -xf /dev/fd/336 -C /content/GPT-SoVITS/ &>/dev/null &
