import os
import http.server
import datetime
from urllib.parse import unquote, urlparse, parse_qs

UPLOAD_DIR = "/content"
PORT = 80

def human_readable_size(size):
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"

class FileServerHandler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        parsed_path = urlparse(self.path)
        query = parse_qs(parsed_path.query)

        if parsed_path.path == '/delete' and 'file' in query:
            filename = query['file'][0]
            safe_name = os.path.basename(unquote(filename))
            filepath = os.path.join(UPLOAD_DIR, safe_name)
            if os.path.isfile(filepath):
                os.remove(filepath)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"DELETED")
            return

        self.directory = UPLOAD_DIR
        return super().do_GET()

    def do_POST(self):
        content_type = self.headers.get('Content-Type', '')
        if not content_type.startswith('multipart/form-data'):
            self.send_error(400, "Expected multipart/form-data")
            return

        boundary = content_type.split("boundary=")[-1].encode()
        remain = int(self.headers['Content-Length'])
        line = self.rfile.readline()
        remain -= len(line)
        if boundary not in line:
            self.send_error(400, "Invalid multipart boundary")
            return

        filename = ""
        while True:
            line = self.rfile.readline()
            remain -= len(line)
            if line.strip() == b'':
                break
            if b'filename=' in line:
                filename = line.decode().split('filename="')[-1].split('"')[0]
                filename = os.path.basename(unquote(filename))

        if not filename:
            self.send_error(400, "No filename")
            return

        filepath = os.path.join(UPLOAD_DIR, filename)
        with open(filepath, 'wb') as f:
            pre = self.rfile.readline()
            remain -= len(pre)
            while remain > 0:
                line = self.rfile.readline()
                remain -= len(line)
                if boundary in line:
                    f.write(pre.rstrip(b'\r\n'))
                    break
                else:
                    f.write(pre)
                    pre = line

        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"OK")

    def list_directory(self, path):
        files = []
        for name in os.listdir(path):
            fullpath = os.path.join(path, name)
            stat = os.stat(fullpath)
            files.append({
                "name": name,
                "size": stat.st_size,
                "mtime": stat.st_mtime,
                "is_dir": os.path.isdir(fullpath),
            })

        html = '''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>文件服务器</title>
<style>
    body {
        background: #1e1e1e;
        color: #ccc;
        font-family: Arial;
        padding: 40px;
        display: flex;
        justify-content: center;
    }
    .container {
        max-width: 900px;
        width: 100%%;
    }
    h2 { color: #fff; text-align: center; }
    input[type=file] {
        display: block;
        margin: 20px auto 10px auto;
        padding: 16px;
        font-size: 16px;
        background: #2d2d2d;
        color: #ccc;
        border: 1px solid #555;
        border-radius: 6px;
        cursor: pointer;
    }
    #uploadControl {
        text-align: center;
        margin-top: 10px;
    }
    #progressBar {
        width: 80%%;
        height: 20px;
        background: #444;
        border-radius: 10px;
        overflow: hidden;
        margin: 10px auto;
        display: none;
    }
    #progressBar div {
    height: 100%;
    background: #00bfff; /* 明亮蓝色 */
    width: 0%;
    transition: width 0.2s ease;
}

    #cancelBtn {
        margin-top: 10px;
        padding: 6px 20px;
        font-size: 14px;
        background: #3a3a3a;
        color: #ccc;
        border: none;
        border-radius: 6px;
        cursor: pointer;
    }
    #cancelBtn:hover {
        background: #555;
    }
    table {
        width: 100%%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        padding: 12px;
        border-bottom: 1px solid #444;
        text-align: left;
    }
    th {
        cursor: pointer;
        color: #eee;
        user-select: none;
    }
    tr:hover {
        background-color: #2a2a2a;
    }
    a {
        color: #4da6ff;
        text-decoration: none;
    }
    a:hover {
        text-decoration: underline;
    }
    .delete-btn {
        background: #3a3a3a;
        padding: 6px 12px;
        margin-left: 10px;
        border: none;
        border-radius: 6px;
        cursor: pointer;
        color: #ccc;
        font-size: 14px;
    }
    .delete-btn:hover {
        background: #555;
    }
</style>
</head>
<body>
<div class="container">
    <h2>📁 文件管理</h2>
    <input type="file" id="fileInput">
    <div id="uploadControl">
        <div id="progressBar"><div></div></div>
        <button id="cancelBtn" style="display:none;">取消上传</button>
    </div>
    <table id="fileTable">
        <thead>
            <tr>
                <th onclick="sortTable('name')">名称</th>
                <th onclick="sortTable('size')">大小</th>
                <th onclick="sortTable('mtime')">修改时间</th>
            </tr>
        </thead>
        <tbody>
'''

        for f in sorted(files, key=lambda x: x["mtime"], reverse=True):
            name = f["name"]
            display = name + '/' if f["is_dir"] else name
            link = name
            size = human_readable_size(f["size"])
            mtime = datetime.datetime.fromtimestamp(f["mtime"]).strftime('%Y-%m-%d %H:%M:%S')
            html += f'''<tr data-name="{name.lower()}" data-size="{f["size"]}" data-mtime="{f["mtime"]}">
<td><a href="{link}">{display}</a><button class="delete-btn" onclick="deleteFile('{name}')">删除</button></td>
<td>{size}</td><td>{mtime}</td></tr>\n'''

        html += '''
        </tbody>
    </table>
</div>
<script>
let currentXhr = null;

document.getElementById("fileInput").addEventListener("change", () => {
    const file = fileInput.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    const xhr = new XMLHttpRequest();
    currentXhr = xhr;

    const progressBar = document.getElementById("progressBar");
    const progress = progressBar.querySelector("div");
    const cancelBtn = document.getElementById("cancelBtn");

    xhr.open("POST", "/", true);

    xhr.upload.onprogress = e => {
        if (e.lengthComputable) {
            let percent = (e.loaded / e.total) * 100;
            progress.style.width = percent.toFixed(1) + "%";
        }
    };

    xhr.onloadstart = () => {
        progress.style.width = "0%";
        progressBar.style.display = "block";
        cancelBtn.style.display = "inline-block";
    };

    xhr.onloadend = () => {
        progressBar.style.display = "none";
        cancelBtn.style.display = "none";
        currentXhr = null;
        refreshFileList();
    };

    xhr.onerror = () => {
        progressBar.style.display = "none";
        cancelBtn.style.display = "none";
        currentXhr = null;
        refreshFileList();
    };

    xhr.send(formData);
});

document.getElementById("cancelBtn").addEventListener("click", () => {
    if (currentXhr) {
        currentXhr.abort();
        currentXhr = null;
        document.getElementById("progressBar").style.display = "none";
        document.getElementById("cancelBtn").style.display = "none";
        refreshFileList();
    }
});

function refreshFileList() {
    fetch(window.location.href)
        .then(res => res.text())
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, "text/html");
            const newTbody = doc.querySelector("#fileTable tbody");
            document.querySelector("#fileTable tbody").replaceWith(newTbody);
        });
}

let sortDirection = 1;
function sortTable(key) {
    const table = document.querySelector("#fileTable tbody");
    const rows = Array.from(table.rows);
    rows.sort((a, b) => {
        let x = a.dataset[key], y = b.dataset[key];
        if (key !== 'name') { x = parseFloat(x); y = parseFloat(y); }
        return (x > y ? 1 : x < y ? -1 : 0) * sortDirection;
    });
    sortDirection *= -1;
    rows.forEach(row => table.appendChild(row));
}

function deleteFile(filename) {
    fetch(`/delete?file=${encodeURIComponent(filename)}`)
        .then(res => res.ok && refreshFileList());
}
</script>

</body>
</html>'''

        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()
        self.wfile.write(html.encode('utf-8'))

if __name__ == "__main__":
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    os.chdir(UPLOAD_DIR)
    httpd = http.server.HTTPServer(("", PORT), FileServerHandler)
    print(f"📂 服务器运行中：http://localhost:{PORT}/")
    httpd.serve_forever()

